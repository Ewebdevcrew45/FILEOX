export { default } from './MobileNetworkBlock';
