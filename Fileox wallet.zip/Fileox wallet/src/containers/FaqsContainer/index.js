export { default } from './FaqsContainer';
