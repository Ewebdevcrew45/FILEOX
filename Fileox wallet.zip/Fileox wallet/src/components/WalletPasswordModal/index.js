export { default } from './WalletPasswordModal';
