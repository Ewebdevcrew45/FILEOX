export { default } from './IpadModal';
