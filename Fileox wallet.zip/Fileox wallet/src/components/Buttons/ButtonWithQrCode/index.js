export { default } from './ButtonWithQrCode';
