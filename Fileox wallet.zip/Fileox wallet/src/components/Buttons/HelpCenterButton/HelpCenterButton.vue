<template>
  <div class="helpcenter-button">
    <div class="wrap">
      Having issues?
      <a
        href="https://kb.myetherwallet.com"
        target="_blank"
        rel="noopener noreferrer"
        >Help Center</a
      >
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {}
};
</script>

<style lang="scss" scoped>
@import 'HelpCenterButton.scss';
</style>
