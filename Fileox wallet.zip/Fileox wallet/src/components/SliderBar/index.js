export { default } from './SliderBar';
