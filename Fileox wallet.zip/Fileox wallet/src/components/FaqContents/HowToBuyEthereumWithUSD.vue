<template>
  <div>
    <h1
      id="articleTitleGUIDEHowtobuyEthereumETHwithUSD"
      class="page__title"
      itemprop="headline"
    >
      [GUIDE] How to buy Ethereum (ETH) with USD
    </h1>
    <div class="content">
      <h3 id="hello-and-welcome-to-ethereum-">
        Hello and welcome to Ethereum!
      </h3>
      <p>
        Ethereum and digital currencies are a pretty new world and in this new
        world, things can be a little bit different. First, you are responsible
        for your stuff. Your investments, your choices, your security. There are
        no babysitters or undo buttons or a bank to call up and reverse your
        transaction. The power of the blockchain is this, but it's also a
        dangerous thing if you are expecting to have all the cushy things you've
        come to enjoy.
      </p>
      <p>
        Secondly, most of the people involved in this world are pretty technical
        and sometimes forget how different things are. Take your time, ask
        questions, ask for clarification reach out for help, read the
        instructions, read the warnings, hang out, and try to learn new things.
      </p>
      <ul>
        <li>
          <p>
            <strong
              >Scams and
              <a
                rel="noopener noreferrer"
                href="https://www.google.com/safebrowsing/static/faq.html#q1"
                >phishing sites</a
              >
              and malicious links exist. Trust messages and random links about
              as much as those in your spambox. Verify verify verify.</strong
            >
          </p>
        </li>
        <li>
          <p>
            <strong
              >Always save &amp; back up your private key in a
              <em>separate</em> location, like a piece of paper or a USB drive.
              Avoid cloud storage.</strong
            >
          </p>
        </li>
        <li>
          <p>
            <strong
              >Be skeptical. Does the person have an ulterior motive? Is that
              too good to be true?</strong
            >
          </p>
        </li>
      </ul>
      <h3 id="still-with-me-good-let-s-dive-deeper-">
        Still with me? Good! Let's dive deeper!
      </h3>

      <ul>
        <li>
          <p>
            <a
              rel="noopener noreferrer"
              href="https://kb.myetherwallet.com/getting-started/whats-the-difference-between-an-exchange-and-myetherwallet.html"
              >Understand the difference between a hosted wallet / exchange and
              client-side wallet before moving your ETH to your own wallet.</a
            >
          </p>
        </li>
        <li>
          <p>
            <a
              rel="noopener noreferrer"
              href="https://kb.myetherwallet.com/getting-started/protecting-yourself-and-your-funds.html"
              >Learn how to protect your funds!</a
            >
          </p>
        </li>
        <li>
          <p>
            <a
              rel="noopener noreferrer"
              href="https://kb.myetherwallet.com/getting-started/getting-back-to-basics-tips-for-newbies.html"
              >10 Tips for Noobs</a
            >
            &amp;
            <a
              rel="noopener noreferrer"
              href="https://kb.myetherwallet.com/getting-started/ethereum-glossary.html"
              >Words are Hard</a
            >
            are both great intros.
          </p>
        </li>
        <li>
          <p>
            <a
              rel="noopener noreferrer"
              href="https://kb.myetherwallet.com/diving-deeper/"
              >And even more links to awesome things just because</a
            >
          </p>
        </li>
      </ul>

      <h3 id="now-the-fun-part-how-to-buy-eth">
        Now, the fun part! How To Buy ETH
      </h3>

      <ol>
        <li><p>Create an account on Gemini or Coinbase or Kraken.</p></li>
        <li>
          <p>
            Verify that account. You will need to upload a wide variety of
            documents proving you are who you say you are and stuff. It's all
            regulatory stuff. Once you upload this stuff, verification takes
            about a day or two (time is dependent on how busy the service is.
            During times of price increases and tons of new users, it may take
            longer. Be patient.)
          </p>
        </li>
        <li>
          <p>
            Follow the instructions on the exchange to deposit USD into that
            exchange. This, depending on your bank and the wire transfer, will
            typically take 3-5 business days.
          </p>
        </li>
        <li>
          <p>
            Now you have USD in your exchange account and can buy ETH with it.
          </p>
        </li>
        <li>
          <p>
            Once you have all the ETH you want, withdraw that ETH into a wallet
            that you control. Exchanges are notorious for being hacked (although
            the ones mentioned above are very reputable) and you want your funds
            in a place that you have the private key to. So...
          </p>
        </li>
        <li>
          <p>
            ...While you are waiting for your verification and transfer,
            download and install
            <a
              rel="noopener noreferrer"
              href="https://github.com/ethereum/mist/releases"
              >Mist / Ethereum Wallet</a
            >. Run it so it can sync the blockchain.
          </p>
        </li>
        <li>
          <p>
            When you run it, it'll prompt you to make a new account. Create a
            password that you will never ever forget and create the account.
            Then, it'll give you an address that starts with 0x.. This what you
            will enter on your exchange to move your ETH from their account to
            your own.
          </p>
        </li>
        <li>
          <p>To safely keep your account you have 3 pieces of information:</p>
          <ul>
            <li>Your address (0x7573aB.....)</li>
            <li>Your password</li>
            <li>Your private key</li>
          </ul>
        </li>
      </ol>

      <p>
        The private key is like a password, but way more intense. Plus, it's a
        password that is protected by another password. In Ethereum Wallet, this
        private key is in the form of a <abbr>keystore file</abbr>. You need to
        make a backup of this in case anything happens to your computer.
      </p>
      <p>
        In Ethereum Wallet, go to the top bar and find <abbr>ACCOUNTS</abbr>
        <i class="fa fa-long-arrow-right" aria-hidden="true" />
        <abbr>BACKUP</abbr>
        <i class="fa fa-long-arrow-right" aria-hidden="true" />
        <abbr>ACCOUNTS</abbr>. It'll open up a folder and inside you will see a
        file. This file is your private key. Copy this to a USB drive and safely
        store the USB drive in a different physical location than your computer
        (in case your house explodes).
      </p>

      <h5>Alternative steps 1-5:</h5>
      <p>
        If you already have BTC, you can use Shapeshift.io, Bity.com, or
        Changelly to convert your BTC into ETH. Start a BTC
        <i class="fa fa-long-arrow-right" aria-hidden="true" /> ETH exchange and
        it'll tell you where to send your BTC. (If you have your BTC on an
        exchange, you can likely exchange them for ETH on that exchange without
        the need for Shapeshift.)
      </p>
      <p>
        Then create a Ethereum Wallet account and back it up. In Circle or
        Coinbase, send all the BTC to that address. The ETH will appear in your
        ETH wallet in ~20 minutes.
      </p>
      <h5>Alternative steps 6-8:</h5>
      <p>
        Mist is highly recommended but some people have issues installing &amp;
        syncing it. If for some reason you cannot get it to run, here is a list
        of easily accessible wallets. Follow the instructions provided by each
        of these wallets to back up your information. In Jaxx, that is a
        mnemonic. In MyEtherWallet,
        <a
          rel="noopener noreferrer"
          href="https://kb.myetherwallet.com/how-do-i-move-from-coinbase-to-myetherwallet-exchange-slash-hosted-wallet-mew"
        >
          read this </a
        >.
      </p>

      <p><strong>Just, MAKE SURE YOU BACK IT UP PLEASE.</strong></p>

      <ul>
        <li>
          <a rel="noopener noreferrer" href="http://www.myetherwallet.com/"
            >MyEtherWallet.com</a
          >
          or
          <a
            rel="noopener noreferrer"
            href="https://www.reddit.com/r/ethereum/comments/44vbef/myetherwallet_chrome_extension_the_beta_has/"
          >
            MEW Chrome Extension
          </a>
        </li>
        <li>
          <a rel="noopener noreferrer" href="http://jaxx.io/">JAXX</a> -
          multi-platform, multi-currency
        </li>
        <li>
          <a rel="noopener noreferrer" href="https://www.exodus.io/"
            >Exodus.io</a
          >
          - multi-currency desktop app
        </li>
      </ul>

      <h5 id="refresher-course-">Refresher Course!</h5>

      <p>
        I have outlined the steps above like you should do it all as fast as
        possible. Stop. Breath. There is no rush. Take your time moving your
        funds from an exchange to your own wallet. Test with a small amount
        first. Get the feel for things and make mistakes with
        <em>small amounts</em> rather than all your money! If you skipped them
        earlier or didn't understand them, take the time to re-read it now.
      </p>

      <ul>
        <li>
          <p>
            <a
              rel="noopener noreferrer"
              href="https://kb.myetherwallet.com/getting-started/whats-the-difference-between-an-exchange-and-myetherwallet.html"
              >Understand the difference between a hosted wallet / exchange and
              client-side wallet before moving your ETH to your own wallet.</a
            >
          </p>
        </li>
        <li>
          <p>
            <a
              rel="noopener noreferrer"
              href="https://kb.myetherwallet.com/getting-started/protecting-yourself-and-your-funds.html"
              >Learn how to protect your funds!</a
            >
          </p>
        </li>
        <li>
          <p>
            <a
              rel="noopener noreferrer"
              href="https://kb.myetherwallet.com/getting-started/getting-back-to-basics-tips-for-newbies.html"
              >10 Tips for Noobs</a
            >
            &amp;
            <a
              rel="noopener noreferrer"
              href="https://kb.myetherwallet.com/getting-started/ethereum-glossary.html"
              >Words are Hard</a
            >
            are both great intros.
          </p>
        </li>
        <li>
          <p>
            <a
              rel="noopener noreferrer"
              href="https://kb.myetherwallet.com/diving-deeper/"
              >And even more links to awesome things just because</a
            >
          </p>
        </li>
      </ul>

      <h5 id="enjoy-">Enjoy!</h5>
      <p>
        <em
          >Originally posted on StackExchange:
          <a
            rel="noopener noreferrer"
            href="https://ethereum.stackexchange.com/questions/1915/how-do-i-buy-ethereum-with-usd"
          >
            https://ethereum.stackexchange.com/questions/1915/how-do-i-buy-ethereum-with-usd
          </a>
        </em>
      </p>
    </div>
  </div></template
>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<style lang="scss" scoped>
@import 'FaqContents.scss';
</style>
