<template>
  <div>
    <h5>
      "Can I send Bitcoin or other coins (LTC STEEM ZEC) to MyEtherWallet?"*
    </h5>
    <p>
      We support <abbr>ETH</abbr>, <abbr>ETC</abbr>, <abbr>Testnet ETH</abbr>,
      <abbr>UBQ</abbr>, <abbr>EXP</abbr>, <abbr>RSK</abbr>,
      <abbr>MUSICOIN</abbr>, and any Ethereum Standard Tokens - aka "ERC-20"
      Tokens.
    </p>

    <p>
      You can use
      <a href="https://bity.com/" target="_blank" rel="noopener noreferrer"
        >Bity.com</a
      >
      or
      <a href="http://shapeshift.io/" target="_blank" rel="noopener noreferrer"
        >Shapeshift.io</a
      >
      or another exchange to swap / convert / exchange your other coins into ETH
      or Ethereum Tokens. However, you do not send those other coins directly to
      your Ethereum address.
    </p>

    <p>
      We recommend
      <a href="https://www.exodus.io/" target="_blank" rel="noopener noreferrer"
        >Exodus.io</a
      >
      as a client-side, mutli-coin solution.
    </p>

    <p>
      Here is a list of default ERC-20 tokens that MEW supports (as of May 28,
      2017). However,
      <a
        href="https://kb.myetherwallet.com/send/sending-and-adding-tokens.html"
        target="_blank"
        rel="noopener noreferrer"
      >
        any ERC-20 token can be added to your local interface by following these
        instructions.
      </a>
    </p>

    <h5>Related Reading</h5>
    <ul>
      <li>
        <a
          href="https://kb.myetherwallet.com/send/adding-new-token-and-sending-custom-tokens.html"
          target="_blank"
          rel="noopener noreferrer"
          >How can I add a non-default token to MEW?</a
        >
      </li>
      <li>
        <a
          href="https://kb.myetherwallet.com/tokens/token-creators-add-your-token-to-myetherwallet.html"
          target="_blank"
          rel="noopener noreferrer"
        >
          I am throwing a #FOMOFest (aka a token sale, token creation period,
          ICO) and want to add my token to MEW for all my investors. What do I
          do?
        </a>
      </li>
    </ul>

    <h5>Default Tokens</h5>

    <ul class="list-in-block">
      <li>1ST</li>
      <li>ADST</li>
      <li>ADT</li>
      <li>ADX</li>
      <li>ANT</li>
      <li>ARC</li>
      <li>BAT</li>
      <li>BeerCoin</li>
      <li>BCDN</li>
      <li>BNC</li>
      <li>BNT</li>
      <li>BQX</li>
      <li>CAT</li>
      <li>CFI</li>
      <li>CRB</li>
      <li>CREDO</li>
      <li>CTL</li>
      <li>CryptoCarbon</li>
      <li>CVC</li>
      <li>DAO</li>
      <li>DDF</li>
      <li>DGD</li>
      <li>DGX 1.0</li>
      <li>DICE</li>
      <li>DRP</li>
      <li>DNT</li>
      <li>EDG</li>
      <li>EMV</li>
      <li>EOS</li>
      <li>FAM</li>
      <li>FUN</li>
      <li>GNO</li>
      <li>GNT</li>
      <li>GUP</li>
      <li>GT</li>
      <li>HKG</li>
      <li>HMQ</li>
      <li>ICN</li>
      <li>JET</li>
      <li>JetCoins</li>
      <li>LUN</li>
      <li>MCAP</li>
      <li>MCO</li>
      <li>MGO</li>
      <li>MDA</li>
      <li>MIT</li>
      <li>MKR</li>
      <li>MLN</li>
      <li>MNE</li>
      <li>MSP</li>
      <li>MTL</li>
      <li>MYST</li>
      <li>NET</li>
      <li>NMR</li>
      <li>NxC</li>
      <li>OAX</li>
      <li>OMG</li>
      <li>PAY</li>
      <li>PLBT</li>
      <li>PTOY</li>
      <li>PLU</li>
      <li>QAU</li>
      <li>QRL</li>
      <li>REP</li>
      <li>RLC</li>
      <li>RLT</li>
      <li>ROUND</li>
      <li>SGEL</li>
      <li>SGT</li>
      <li>SHIT</li>
      <li>SKIN</li>
      <li>SKO1</li>
      <li>SNGLS</li>
      <li>SNM</li>
      <li>SNT</li>
      <li>SRC</li>
      <li>STORJ</li>
      <li>SWT</li>
      <li>SNC</li>
      <li>TaaS</li>
      <li>TFL</li>
      <li>TIME</li>
      <li>TIX</li>
      <li>TKN</li>
      <li>TRST</li>
      <li>Unicorn</li>
      <li>VSL</li>
      <li>VSM</li>
      <li>VERI</li>
      <li>VRS</li>
      <li>WINGS</li>
      <li>XAUR</li>
      <li>XID</li>
      <li>XRL</li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<style lang="scss" scoped>
@import 'FaqContents.scss';
</style>
