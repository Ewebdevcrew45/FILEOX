<template>
  <div>
    <p>
      Here is a list of reputable services you can use the following services to
      buy and sell ETH / Tokens / fiat (USD, EUR, etc.). There are many, many
      more out there but these are the ones I am familar with.
    </p>
    <p>
      Always google " scam" and read about people's experiences before choosing
      to send to a random service or website.
    </p>
    <p>
      Not all exchanges support all coin types and fiat types, so take a look
      around to find one that fits your location and circumstances.
    </p>

    <ul>
      <li>
        Bitfinex:
        <a
          href="https://www.bitfinex.com/"
          target="_blank"
          rel="noopener noreferrer"
          >Website</a
        >
        ·
        <a rel="noopener noreferrer" href="https://www.bitfinex.com/support"
          >Support</a
        >
      </li>
      <li>
        Bittrex:
        <a
          href="https://bittrex.com/Home/Markets"
          target="_blank"
          rel="noopener noreferrer"
          >Website</a
        >
        ·
        <a rel="noopener noreferrer" href="https://bittrex.com/Home/Contact"
          >Support</a
        >
      </li>
      <li>
        Bity:
        <a
          href="https://bity.com/af/jshkb37v"
          target="_blank"
          rel="noopener noreferrer"
          >Website</a
        >
        ·
        <a rel="noopener noreferrer" href="mailto:support@bity.com">Support</a>
      </li>
      <li>
        Changelly:
        <a
          href="https://changelly.com/about"
          target="_blank"
          rel="noopener noreferrer"
          >Website</a
        >
        ·
        <a rel="noopener noreferrer" href="mailto:support@changelly.com"
          >Support</a
        >
      </li>
      <li>
        Coinbase:
        <a
          href="https://support.coinbase.com/"
          target="_blank"
          rel="noopener noreferrer"
          >Support</a
        >
      </li>
      <li>
        Gemini:
        <a
          href="https://gemini24.zendesk.com/hc/en-us/requests/new"
          target="_blank"
          rel="noopener noreferrer"
          >Support</a
        >
        ·
        <a
          rel="noopener noreferrer"
          href="https://gemini24.zendesk.com/hc/en-us"
          >FAQ</a
        >
      </li>
      <li>
        Kraken:
        <a
          href="https://support.kraken.com/hc/en-us"
          target="_blank"
          rel="noopener noreferrer"
          >Support</a
        >
      </li>
      <li>
        Liqui:
        <a
          href="https://liqui.freshdesk.com/support/home"
          target="_blank"
          rel="noopener noreferrer"
          >Support</a
        >
      </li>
      <li>
        Poloniex:
        <a
          href="https://poloniex.com/support/"
          target="_blank"
          rel="noopener noreferrer"
          >Support</a
        >
      </li>
      <li>
        Shapeshift:
        <a
          href="https://shapeshiftcommunity.herokuapp.com/"
          target="_blank"
          rel="noopener noreferrer"
          >Slack</a
        >
        ·
        <a
          href="https://www.reddit.com/r/shapeshiftio"
          target="_blank"
          rel="noopener noreferrer"
          >Reddit</a
        >
        ·
        <a
          href="https://shapeshift.zendesk.com/hc/en-us/requests/new"
          target="_blank"
          rel="noopener noreferrer"
          >Support</a
        >
      </li>
    </ul>

    <p>Best of luck!</p>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<style lang="scss" scoped>
@import 'FaqContents.scss';
</style>
