<template>
  <div>
    <p>
      If you are on
      <a href="https://www.myetherwallet.com/" rel="noopener noreferrer"
        >https://www.myetherwallet.com/</a
      >
      and connected to a node that supports it, you can see the current block
      number in small print in footer of the page.
    </p>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<style lang="scss" scoped>
@import 'FaqContents.scss';
</style>
