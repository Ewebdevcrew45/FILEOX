<template>
  <div>
    <p>
      Decrypting the keystore files is an intensive process and doesn't enjoy
      being done in Javascript. We recommend...
    </p>
    <ol>
      <li>Using Google Chrome</li>
      <li>
        Clicking "continue" when you see the unresponsive error alert pop up
      </li>
      <li>
        Making sure you don't have other intensive programs open (a lot of
        browser tabs, video games, etc.)
      </li>
    </ol>
    <p>
      The combination of the above typically eliminate the problem. If it
      doesn't, please contact us with your browser and OS and we can advise from
      there.
    </p>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<style lang="scss" scoped>
@import 'FaqContents.scss';
</style>
