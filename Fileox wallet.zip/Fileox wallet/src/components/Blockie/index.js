export { default } from './Blockie';
