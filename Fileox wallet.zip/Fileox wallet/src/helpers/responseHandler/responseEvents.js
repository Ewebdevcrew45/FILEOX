const WARN = 1;
const SUCCESS = 2;
const ERROR = 3;
const INFO = 4;

export { WARN, SUCCESS, ERROR, INFO };
