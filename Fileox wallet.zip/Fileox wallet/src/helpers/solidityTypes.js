const uint = 'uint';
const address = 'address';
const string = 'string';
const bytes32 = 'bytes32[]';
const bytes = 'bytes';
const bool = 'bool';

export { uint, address, string, bytes32, bytes, bool };
