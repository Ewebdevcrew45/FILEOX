const wallet = {
  kdf: 'scrypt',
  n: 131072
};
export default {
  wallet
};
