export { default } from './AccessWalletLayout';
