export { default } from './SoftwareModal';
