export { default } from './PriceBar';
