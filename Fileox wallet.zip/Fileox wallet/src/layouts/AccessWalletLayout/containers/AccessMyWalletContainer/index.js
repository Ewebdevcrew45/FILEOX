export { default } from './AccessMyWalletContainer';
