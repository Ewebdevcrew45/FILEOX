export { default } from './Congratulations';
