export { default } from './DevelopmentResources';
