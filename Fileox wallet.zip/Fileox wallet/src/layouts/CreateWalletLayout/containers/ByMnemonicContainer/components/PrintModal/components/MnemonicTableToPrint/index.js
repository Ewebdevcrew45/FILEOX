export { default } from './MnemonicTableToPrint';
