export { default } from './VerificationModal';
