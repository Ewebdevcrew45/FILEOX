export { default } from './MnemonicTableToDisplay';
