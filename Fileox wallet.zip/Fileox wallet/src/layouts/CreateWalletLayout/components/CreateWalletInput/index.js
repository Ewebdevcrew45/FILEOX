export { default } from './CreateWalletInput';
