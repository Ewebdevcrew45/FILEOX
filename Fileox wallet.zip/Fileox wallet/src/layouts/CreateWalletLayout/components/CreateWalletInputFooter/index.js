export { default } from './CreateWalletInputFooter';
