import { Misc } from '@/helpers';
const Capitalize = Misc.capitalize;

export default Capitalize;
