export { default } from './TransferRegistrarsContainer';
