export { default } from './ClaimDNSContainer';
