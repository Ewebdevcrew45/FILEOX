export { default } from './PrintModal.vue';
