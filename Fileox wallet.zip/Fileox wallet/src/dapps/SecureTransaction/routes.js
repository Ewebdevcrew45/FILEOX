import SecureTransaction from './SecureTransaction';

export default {
  path: 'dapps/secure-transaction',
  name: 'Secure Transaction',
  component: SecureTransaction,
  props: true
};
