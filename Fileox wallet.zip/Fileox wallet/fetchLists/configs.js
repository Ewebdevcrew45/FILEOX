module.exports = {
  MAIN_LISTS_PATH: './fetchLists/lists',
  TOKENS_PATH: './src/tokens',
  CONTRACTS_PATH: './src/contracts',
  DARKLIST_PATH: './src/darklist'
};
