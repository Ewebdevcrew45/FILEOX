#!/usr/bin/env sh

set -e

ccache --cleanup
ccache --show-stats
